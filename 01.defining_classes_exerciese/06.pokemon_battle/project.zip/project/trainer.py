

class Trainer:

    def __init__(self, name):
        self.name = name
        self.pokemon = []

    def add_pokemon(self, current_pokemon):
        if current_pokemon in self.pokemon:
            return 'This pokemon is already caught'
        self.pokemon.append(current_pokemon)
        return f'Caught {self.name} with health {self.health}'

    def release_pokemon(self, pokemon_name):
        pokemon_names = [p.name for p in self.pokemon]
        if pokemon_name in pokemon_names:
            del self.pokemon[pokemon_name.index(pokemon_name)]
            return f'You have released {pokemon_name}'
        else:
            return 'Pokemon is not caught'

    def trainer_data(self):
        output = f'Pokemon Trainer {self.name}\n'
        output += f'Pokemon count {len(self.pokemon)}\n'
        for poke in self.pokemon:
            output += '- ' + poke.pokemon_details() + '\n'
        return output


